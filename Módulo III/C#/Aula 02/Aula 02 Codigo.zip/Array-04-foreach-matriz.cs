using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int[,] matriz =
			{
				{ 3, 7, 8, 2 },
				{ 5, 6, 1, 4 }
			};

			foreach (int numero in matriz)
			{
				Console.WriteLine(numero);
			}

			Console.ReadKey();
		}
	}
}



