using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

namespace CRUDApp
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				Console.Write("Entre o ID do empregado: ");
				int empid = Convert.ToInt32(Console.ReadLine());

				Console.Write("Entre o nome do empregado: ");
				string name = Console.ReadLine();

				Console.Write("Entre o salário do empregado: ");
				decimal salary = Convert.ToDecimal(Console.ReadLine());

				string query = "insert into emp values(" +
					empid + ", '" + name + "', " + salary + ")";
				Console.WriteLine(query);

				string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Alexandre\source\repos\CRUDApp\Database1.mdf;Integrated Security=True";
				SqlConnection cn = new SqlConnection(cs);
				cn.Open();

				Console.WriteLine("Conexão estabelecida!");

				SqlCommand cmd = new SqlCommand(query, cn);
				int result = cmd.ExecuteNonQuery();
				Console.WriteLine(result + " dados gravados na tabela emp.");

				Console.WriteLine("------Para recuperar dados-------");
				query = "select * from emp";
				SqlCommand cmd1 = new SqlCommand(query, cn);
				// instância separada do comando sql 
				// é necessária para executar cada consulta sql
				SqlDataReader r = cmd1.ExecuteReader();
				while (r.Read() == true)
				{
					int eid = r.GetInt32(0); // 0-indice da coluna [empid]
					string nm = r.GetString(1); // 1-indice da coluna [name]
					decimal sal = r.GetDecimal(2); //2-indice da coluna [salary]
					Console.WriteLine("{0}\t {1}\t {2}",
						eid, nm, sal);
				}
				cn.Close();
			}
			catch (Exception e)
			{
				Console.WriteLine(e);
			}
			Console.ReadKey();
		}
	}
}

