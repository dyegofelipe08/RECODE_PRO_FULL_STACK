using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			// array de uma dimensão
			int[] valor1 = new int[4];
			valor1[0] = 1;
			valor1[1] = 2;
			valor1[2] = 3;
			valor1[3] = 4;

			// array de duas dimensões
			int[,] numeros = new int[3, 2]
			{
				{ 1, 2 },
				{ 3, 4 },
				{ 5, 6 }
			};

			Console.ReadKey();
		}
	}
}
