using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int valor = 0;
			while (valor < 10)
			{
				Console.WriteLine("Essa é a repetição = " + valor);

				valor = valor + 1;
			}
			Console.ReadKey();
		}
	}
}
