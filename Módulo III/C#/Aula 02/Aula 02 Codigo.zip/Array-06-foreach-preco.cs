using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int[] preco = { 300, 700, 800, 200, 500, 600, 100, 400 };

			foreach (int orcamento in preco)
			{
				if (orcamento <= 400 && orcamento >= 100 )
				{
				Console.WriteLine(orcamento);
				}
			}
			Console.ReadKey();
		}
	}
}



