using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Veja seus descontos");
			Console.Write("Até quantas peças pretende levar hoje? ");
			int qtdeRoupa = int.Parse(Console.ReadLine());
			double vlrRoupa = 100;
			double desc = 0.05;
			double descMax = 0.25;

			for (int cont = 1; cont <= qtdeRoupa; cont++)
			{
				if (cont <=5)
				{
					Console.WriteLine("Valor R${0} desconto = R${1}", vlrRoupa * cont, vlrRoupa * cont * (desc*cont));	
				}
				else
				{
					Console.WriteLine("Valor R${0} desconto = R${1}", vlrRoupa * cont, vlrRoupa * cont * descMax);
				}
			}
			Console.ReadKey();
		}
	}
}
