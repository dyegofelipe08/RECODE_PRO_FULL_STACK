using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int milhasGanhas = 400;
			int contador = 1;

			Console.Write("Entre com a qtde de viagens: ");
			int qteViagem = int.Parse(Console.ReadLine());

			while (qteViagem > contador)
			{
				Console.WriteLine("Milhas da viagem " + contador + " = " + contador*milhasGanhas);

				contador = contador + 1;
			}
			Console.ReadKey();
		}
	}
}
