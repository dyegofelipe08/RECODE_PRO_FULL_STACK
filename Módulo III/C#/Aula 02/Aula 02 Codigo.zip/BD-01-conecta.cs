using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

namespace CRUDApp
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Alexandre\source\repos\CRUDApp\Database1.mdf;Integrated Security=True";
				SqlConnection cn = new SqlConnection(cs);
				cn.Open();

				Console.WriteLine("Conexão estabelecida!");

				cn.Close();
			}
			catch (Exception e)
			{
				Console.WriteLine(e);
			}
			Console.ReadKey();
		}
	}
}
