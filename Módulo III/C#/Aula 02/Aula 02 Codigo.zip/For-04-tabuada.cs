using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.Write("Digite a tabuada: ");
			int tab = int.Parse(Console.ReadLine());
			
			for (int contador = 0; contador < 10; contador++)
			{
				Console.WriteLine("{0} X {1} = {2}", tab, contador, tab*contador);
			}
			Console.ReadKey();
		}
	}
}


 



