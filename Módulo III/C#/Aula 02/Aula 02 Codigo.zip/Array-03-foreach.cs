using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			char[] alfabeto = { 'A', 'B', 'C', 'D', 'E' };

			for (int cont = 0; cont < alfabeto.Length; cont++)
			{
				// declaro a variável letra como sendo do tipo char
				// alfabeto[cont] é armazenado na variável letra do tipo char
				char letra = alfabeto[cont];

				// aqui é mostrado o valor da variável letra.
				Console.WriteLine(letra);
			}
			
			// foreach = para cada
			foreach (char letra in alfabeto)
			{
				Console.WriteLine(letra);
			}

			Console.ReadKey();
		}
	}
}



