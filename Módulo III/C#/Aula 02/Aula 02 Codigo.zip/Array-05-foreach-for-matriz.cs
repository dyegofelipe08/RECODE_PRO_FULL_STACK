using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int[,] matriz =
			{
				{ 3, 7, 8, 2 },
				{ 5, 6, 1, 4 }
			};

			foreach (int numero in matriz)
			{
				Console.WriteLine(numero);
			}

			for (int i = 0; i < matriz.GetLength(0); i++)
			{
				for (int j = 0; j < matriz.GetLength(1); j++)
				{
					int n = matriz[i, j];
					Console.WriteLine(n);
				}
			}
			Console.ReadKey();
		}
	}
}



