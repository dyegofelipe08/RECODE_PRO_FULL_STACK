using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			char[] alfabeto = { 'A', 'B', 'C', 'D', 'E' };

			for (int cont = 0; cont < alfabeto.Length; cont++)
			{
				// declaro a variável letra como sendo do tipo char
				char letra = alfabeto[cont];

				Console.WriteLine(letra);
			}

			Console.ReadKey();
		}
	}
}
