using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int i = 0;
			while (i < 10)
			{
				// Console.WriteLine("i = " + i);  
				Console.WriteLine("i = {0}", i);

				// Interpolação de valores com { }

				// i = i + 1;
				i++;

			}
			Console.ReadKey();
		}
	}
}

