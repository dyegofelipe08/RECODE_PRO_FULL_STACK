using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int valor = 10;
			do
			{
				Console.WriteLine("Esse é o tamanho = " + valor);
				// valor--;
				valor = valor - 1;

			} while (valor > 0);

			Console.ReadKey();
		}
	}
}


