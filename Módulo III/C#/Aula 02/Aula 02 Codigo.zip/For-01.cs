using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			for (int valor = 1; valor <= 10; valor++)
			{
				Console.WriteLine("Repetição (estrutura for) número = " + valor);
			}

			Console.ReadKey();
		}
	}
}
 



