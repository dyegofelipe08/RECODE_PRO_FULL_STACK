using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AspnRazorPage1.Models
{
	public class Cliente
	{
		public int Id { get; set; }
		[Required, StringLength(100)]
		public string Nome { get; set; }
	}
}