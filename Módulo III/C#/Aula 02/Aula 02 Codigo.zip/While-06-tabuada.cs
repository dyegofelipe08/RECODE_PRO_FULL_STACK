using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int valor = 1;

			Console.Write("Entre com o valor da tabuada: ");
			int valTab = int.Parse(Console.ReadLine());

			while (valor < 10)
			{
				Console.WriteLine(valTab + " X " + valor + " = " + valTab*valor);

				valor = valor + 1;
			}
			Console.ReadKey();
		}
	}
}
