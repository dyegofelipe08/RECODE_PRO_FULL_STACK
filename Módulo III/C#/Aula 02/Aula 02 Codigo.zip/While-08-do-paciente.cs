using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int diasDeInter = 1;
			

			Console.WriteLine("Plano de Saude - Dias de Internação");
			Console.Write("Entre com a qtde. autorizada: ");
			int qtdeAutoriz = int.Parse(Console.ReadLine());
			do
			{
				Console.WriteLine("Atender o paciente - dia " + diasDeInter );
				diasDeInter = diasDeInter + 1;

			} while (qtdeAutoriz > diasDeInter );

			Console.ReadKey();
		}
	}
}







